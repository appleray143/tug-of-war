@echo off
title Radical Rally Server
node server.js
pause
