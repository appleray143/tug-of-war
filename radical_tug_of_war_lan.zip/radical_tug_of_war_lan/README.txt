RADICAL RALLY - SAME WI-FI MULTIPLAYER

1. Install Node.js on the teacher computer if it is not yet installed.
2. Double-click START_GAME_WINDOWS.bat (Windows), or run: node server.js
3. The black window shows addresses such as http://192.168.1.5:8080
4. Open that address on the teacher computer and all learner devices connected to the SAME Wi-Fi.
5. Teacher selects Create Room and shares the four-character room code.
6. Learners enter their name and room code.

IMPORTANT
- Keep the server window open during the game.
- If phones cannot connect, allow Node.js through Windows Firewall for Private networks.
- Guest Wi-Fi or Access Point Isolation can block device-to-device communication. Use a normal private hotspot/router.
- Internet is not needed after Node.js is installed.
- Questions do not repeat within a room because each generated expression is recorded.
